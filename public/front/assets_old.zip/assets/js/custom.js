AOS.init({
  once: true,
});

// text edtior start

// ClassicEditor.create(document.querySelector("#editor")).catch((error) => {
//   console.error(error);
// });

// text edtior end
